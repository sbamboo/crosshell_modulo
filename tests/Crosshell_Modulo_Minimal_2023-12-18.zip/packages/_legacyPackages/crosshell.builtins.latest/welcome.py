from cslib import writeWelcome

writeWelcome(csSession)
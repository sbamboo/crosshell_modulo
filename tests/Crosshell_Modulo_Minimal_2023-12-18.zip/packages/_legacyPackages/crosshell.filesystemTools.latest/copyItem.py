from cslib.externalLibs.filesys import filesys as fs
fs.copyFile(*argv)
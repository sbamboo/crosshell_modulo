import os
print(os.path.basename(sargv.strip(" ")))
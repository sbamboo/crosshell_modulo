from cslib.externalLibs.filesys import filesys as fs
fs.copyFolder2()(*argv)
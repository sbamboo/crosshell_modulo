import socket
print( socket.gethostname() )
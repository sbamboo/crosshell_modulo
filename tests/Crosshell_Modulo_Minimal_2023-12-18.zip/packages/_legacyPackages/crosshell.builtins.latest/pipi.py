from cslib import intpip

intpip(sargv)
import os
os.system(sargv)

from cslib.externalLibs.conUtils import clear
clear()
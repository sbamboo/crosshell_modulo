from cslib.externalLibs.filesys import filesys as fs
fs.openFolder(CS_BaseDir)
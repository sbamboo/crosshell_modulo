sargv = sargv.strip("\n")
print("{f.red}"+sargv+"{r}")
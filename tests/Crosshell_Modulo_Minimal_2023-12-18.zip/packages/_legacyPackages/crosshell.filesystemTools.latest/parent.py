import os
print(os.path.dirname(sargv.strip(" ")))
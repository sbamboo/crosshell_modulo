import os
columns, rows = os.get_terminal_size()

if CS_InPipeline:
    print(f"{columns},{rows}")
else:
    print(f'Columns: {columns}\nRows: {rows}')
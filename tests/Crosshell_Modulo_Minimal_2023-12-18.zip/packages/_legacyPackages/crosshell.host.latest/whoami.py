import socket
import getpass
print( f"{socket.gethostname()}\{getpass.getuser()}" )
from cslib.externalLibs.filesys import filesys as fs
print( fs.readFromFile(*argv) )